package com.fdmgroup.app.data;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fdmgroup.app.model.Employee;


@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    List<Employee> findAllByAddress_StreetContains(String street);
    List<Employee> findAllByAddress_CityContains(String city);
    List<Employee> findAllByAddress_StateContains(String state);
    List<Employee> findAllByAddress_CountryContains(String country);


}