package com.fdmgroup.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.fdmgroup.app.model.Address;
import com.fdmgroup.app.service.AddressService;

@Controller
public class AddressController {

    private AddressService addressService;

    @Autowired
    public AddressController(AddressService addressService) {
        super();
        this.setAddressService(addressService);
    }


    //display list of address
    @GetMapping("/addAddress")
    public String toAddAddress(Model model) {
        model.addAttribute("address", new Address());
        return "add-address";
    }


	public AddressService getAddressService() {
		return addressService;
	}


	public void setAddressService(AddressService addressService) {
		this.addressService = addressService;
	}

}